"""
@File: Net.py
@Time: 2023/11/30
@Author: rp
@Software: PyCharm

"""
import builtins
import os

from thop import profile, clever_format

os.environ["CUDA_VISIBLE_DEVICES"] = "1"
print('USE GPU 1')

import torch
import torch.nn.functional as F
import torch.distributed as dist
import numpy as np
from datetime import datetime

from torch import nn, optim
from torchvision.utils import make_grid
from tool.dataset import get_loader, test_dataset
from tool.tools import clip_gradient, adjust_lr
from tensorboardX import SummaryWriter
import logging
import torch.backends.cudnn as cudnn
from lib.Net import Net
from tool.tools import seed_torch
from lib.loss_demo import SimMinLoss, SCLoss, SimMaxLoss, CACLoss
from lib.mssim import ssim

seed_torch()
SimMinLoss = SimMinLoss(metric='cos', reduction='mean', )
SimMaxLoss_bg = SimMaxLoss(metric='cos', reduction='mean', alpha=0.05)
SimMaxLoss_fg = SimMaxLoss(metric='cos', reduction='mean', alpha=0.05)

SCLoss = SCLoss()
cac_loss = CACLoss(alpha=1.0, lambda_drw=1.0)

def get_coef(iter_percentage=1, method="cos", milestones=(0, 1)):
    min_point, max_point = min(milestones), max(milestones)
    min_coef, max_coef = 0, 1

    ual_coef = 1.0
    if iter_percentage < min_point:
        ual_coef = min_coef
    elif iter_percentage > max_point:
        ual_coef = max_coef
    else:
        if method == "linear":
            ratio = (max_coef - min_coef) / (max_point - min_point)
            ual_coef = ratio * (iter_percentage - min_point)
        elif method == "cos":
            perc = (iter_percentage - min_point) / (max_point - min_point)
            normalized_coef = (1 - np.cos(perc * np.pi)) / 2
            ual_coef = normalized_coef * (max_coef - min_coef) + min_coef
    return ual_coef


def bce_ual_loss(pred, mask, ):
    prob = pred.sigmoid()
    bce_loss = F.binary_cross_entropy_with_logits(pred, mask, )
    ual_loss = get_coef(iter_percentage=1, method='cos', milestones=(0, 1))
    ual_loss = ual_loss * (1 - (2 * prob - 1).abs().pow(2)).mean()
    return bce_loss + ual_loss

def structure_loss(pred, mask):
    weit = 1 + 5 * torch.abs(F.avg_pool2d(mask, kernel_size=31, stride=1, padding=15) - mask)
    wbce = F.binary_cross_entropy_with_logits(pred, mask, )
    wbce = (weit * wbce).sum(dim=(2, 3)) / weit.sum(dim=(2, 3))

    pred = torch.sigmoid(pred)
    inter = ((pred * mask) * weit).sum(dim=(2, 3))
    union = ((pred + mask) * weit).sum(dim=(2, 3))
    wiou = 1 - (inter + 1) / (union - inter + 1)
    return (wbce + wiou).mean()


TML = torch.nn.TripletMarginLoss(margin=1.0, p=2.0, eps=1e-6, swap=False, reduction='mean')


def iou(prob, gt):
    inter = torch.sum(gt * prob, dim=(1, 2, 3))
    union = gt.sum(dim=(1, 2, 3)) + prob.sum(dim=(1, 2, 3)) - inter
    iou = inter / union
    return iou.mean()


def loss_func(logits, seg_gts):
    losses = []
    bce_loss = torch.nn.functional.binary_cross_entropy_with_logits(input=logits, target=seg_gts, reduction="mean")
    losses.append(bce_loss)
    prob = logits.sigmoid()
    ssim_loss = 1 - ssim(prob, seg_gts)
    losses.append(ssim_loss)
    iou_loss1 = 1 - iou(prob, seg_gts)
    losses.append(iou_loss1)
    return sum(losses)


def train(train_loader, model, optimizer, epoch, save_path):
    global step
    model.train()
    loss_all = 0
    epoch_step = 0

    try:
        for i, (images, gts, depth) in enumerate(train_loader, start=1):
            optimizer.zero_grad()
            images = images.cuda()
            gts = gts.cuda()
            depth = depth.repeat(1, 3, 1, 1).cuda()

            s, s1, s2, s3, fg, bg = model(images, depth)

            # fusion1 = F.upsample(fusion1, size=gts.shape[2:], mode='bilinear', align_corners=False)
            # fusion2 = F.upsample(fusion2, size=gts.shape[2:], mode='bilinear', align_corners=False)
            # fusion3 = F.upsample(fusion3, size=gts.shape[2:], mode='bilinear', align_corners=False)
            # fusion4 = F.upsample(fusion4, size=gts.shape[2:], mode='bilinear', align_corners=False)
            #
            # loss_tml1 = TML(fusion1, gts * fusion1, (1 - gts) * fusion1)
            # loss_tml2 = TML(fusion2, gts * fusion2, (1 - gts) * fusion2)
            # loss_tml3 = TML(fusion3, gts * fusion3, (1 - gts) * fusion3)
            # loss_tml4 = TML(fusion4, gts * fusion4, (1 - gts) * fusion4)

            # loss_triplet = (loss_tml1 + loss_tml2 + loss_tml3 + loss_tml4) / 4.0
            sim_loss = SimMinLoss(bg, fg)
            # sim_min_loss = SimMinLoss(bg, fg)
            sim_max_loss_bg = SimMaxLoss_bg(bg)
            sim_max_loss_fg = SimMaxLoss_fg(fg)

            sal_loss = loss_func(s, gts)
            sal_loss1 = loss_func(s1, gts)
            sal_loss2 = loss_func(s2, gts)
            sal_loss3 = loss_func(s3, gts)
            # sal_loss = structure_loss(s, gts)
            # sal_loss1 = structure_loss(s1, gts)
            # sal_loss2 = structure_loss(s2, gts)
            # sal_loss3 = structure_loss(s3, gts)
            # sal_loss4 = structure_loss(s4, gts)

            # loss_sal = sal_loss + sal_loss1 + sal_loss2 + sal_loss3 + sal_loss4 + 0.8*sim_loss
            # loss_sal = sal_loss + sal_loss1 + sal_loss2 + sal_loss3 + sim_max_loss_bg + sim_max_loss_fg + sim_loss
            loss_sal = sal_loss + sal_loss1 + sal_loss2 + sal_loss3
            loss = loss_sal

            loss.backward()

            clip_gradient(optimizer, opt.clip)
            optimizer.step()
            # scaler.step(optimizer)
            # scaler.update()
            step += 1
            epoch_step += 1
            if i % 100 == 0 or i == total_step or i == 1:
                # loop.set_description(f'Epoch [{epoch}]')
                # loop.set_postfix(salloss=sal_loss.data,edge_loss=edge_loss.data,salloss1=sal_loss1.data)
                print(
                    '{} Epoch [{:03d}/{:03d}], Step [{:04d}/{:04d}], LR:{:.7f} loss:{:4f} ||sal_loss:{:4f}, '.
                    format(datetime.now(), epoch, opt.epoch, i, total_step,
                           optimizer.state_dict()['param_groups'][0]['lr'], loss.data, sal_loss.data))
                logging.info(
                    '#TRAIN#:Epoch [{:03d}/{:03d}], Step [{:04d}/{:04d}], LR:{:.7f}, loss:{:4f} ||sal_loss:{:4f} ||'.
                    format(epoch, opt.epoch, i, total_step, optimizer.state_dict()['param_groups'][0]['lr'], loss.data,
                           sal_loss.data,))
                writer.add_scalar('Loss', loss.data, global_step=step)
                grid_image = make_grid(images[0].clone().cpu().data, 1, normalize=True)
                writer.add_image('RGB', grid_image, step)
                grid_image = make_grid(gts[0].clone().cpu().data, 1, normalize=True)
                writer.add_image('Ground_truth', grid_image, step)
                res = s[0].clone()
                res = res.sigmoid().data.cpu().numpy().squeeze()
                res = (res - res.min()) / (res.max() - res.min() + 1e-8)
                writer.add_image('res', torch.tensor(res), step, dataformats='HW')
        # sal_loss_all /= epoch_step
        loss_all /= epoch_step
        logging.info('#TRAIN#:Epoch [{:03d}/{:03d}],Loss_AVG: {:.4f}'.format(epoch, opt.epoch, loss_all))
        writer.add_scalar('Loss-epoch', loss_all, global_step=epoch)
        if (epoch) % 5 == 0:
            torch.save(model.state_dict(), save_path + 'CatNet_epoch_{}.pth'.format(epoch))
    except KeyboardInterrupt:
        print('Keyboard Interrupt: save model and exit.')
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        torch.save(model.state_dict(), save_path + 'CatNet_epoch_{}.pth'.format(epoch + 1))
        print('save checkpoints successfully!')
        raise


def val(test_loader, model, epoch, save_path):
    global best_mae, best_epoch
    model.eval()
    with torch.no_grad():
        mae_sum = 0
        for i in range(test_loader.size):
            image, gt, depth, name, img_for_post = test_loader.load_data()
            gt = np.asarray(gt, np.float32)
            gt /= (gt.max() + 1e-8)
            image = image.cuda()
            depth = depth.repeat(1, 3, 1, 1).cuda()
            res, _, _, _, fg, bg = model(image, depth)
            res = F.upsample(res, size=gt.shape, mode='bilinear', align_corners=False)
            res = res.sigmoid().data.cpu().numpy().squeeze()
            res = (res - res.min()) / (res.max() - res.min() + 1e-8)
            mae_sum += np.sum(np.abs(res - gt)) * 1.0 / (gt.shape[0] * gt.shape[1])
        mae = mae_sum / test_loader.size
        writer.add_scalar('MAE', torch.tensor(mae), global_step=epoch)
        print('Epoch: {} MAE: {} ####  bestMAE: {} bestEpoch: {}'.format(epoch, mae, best_mae, best_epoch))
        if epoch == 1:
            best_mae = mae
        else:
            if mae < best_mae:
                best_mae = mae
                best_epoch = epoch
                torch.save(model.state_dict(), save_path + 'CatNet_epoch_best.pth')
                print('best epoch:{}'.format(epoch))
        logging.info('#TEST#:Epoch:{} MAE:{} bestEpoch:{} bestMAE:{}'.format(epoch, mae, best_epoch, best_mae))


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--epoch', type=int, default=100, help='epoch number')
    parser.add_argument('--lr', type=float, default=1e-4, help='learning rate')
    parser.add_argument('--batchsize', type=int, default=8, help='training batch size')
    parser.add_argument('--trainsize', type=int, default=384, help='training dataset size')
    parser.add_argument('--clip', type=float, default=0.5, help='gradient clipping margin')
    parser.add_argument('--decay_rate', type=float, default=0.1, help='decay rate of learning rate')
    parser.add_argument('--decay_epoch', type=int, default=50, help='every n epochs decay learning rate')
    # parser.add_argument('--load', type=str, default=None, help='train from checkpoints')
    parser.add_argument('--gpu', type=str, default=None, help='train use gpu')
    parser.add_argument('--train_root', type=str, default='/home/renpeng/COD_Datasets/TrainDataset/',
                        help='the training rgb images root')
    parser.add_argument('--val_root', type=str, default='/home/renpeng/COD_Datasets/Test/CAMO/',
                        help='the test gt images root')
    parser.add_argument('--save_path', type=str, default='./snapshot1/Exp35/', help='the path to save model and log')

    # DDP configs:
    # parser.add_argument('--world-size', default=-1, type=int,
    #                     help='number of nodes for distributed training')
    # parser.add_argument('--rank', default=-1, type=int,
    #                     help='node rank for distributed training')
    # parser.add_argument('--dist-url', default='env://', type=str,
    #                     help='url used to set up distributed training')
    # parser.add_argument('--dist-backend', default='nccl', type=str,
    #                     help='distributed backend')
    # parser.add_argument('--local-rank', default=-1, type=int,
    #                     help='local rank for distributed training')
    opt = parser.parse_args()


    # if "WORLD_SIZE" in os.environ:
    #     opt.world_size = int(os.environ["WORLD_SIZE"])
    # opt.distributed = opt.world_size > 1
    # ngpus_per_node = torch.cuda.device_count()
    # local_rank = int(os.environ["LOCAL_RANK"])
    # if opt.distributed:
    #     if local_rank != -1:  # for torch.distributed.launch
    #         opt.rank = local_rank
    #         opt.gpu = local_rank
    #     elif 'SLURM_PROCID' in os.environ:  # for slurm scheduler
    #         opt.rank = int(os.environ['SLURM_PROCID'])
    #         opt.gpu = opt.rank % torch.cuda.device_count()
    #         print('******')
    #         print("opt.rank = {}; opt.gpu = {}".format(opt.rank, opt.gpu))
    #     dist.init_process_group(backend=opt.dist_backend, init_method=opt.dist_url,
    #                             world_size=opt.world_size, rank=opt.rank)
    #
    # # suppress printing if not on master gpu
    # if opt.rank != 0:
    #     def print_pass(*args):
    #         pass
    #
    #     builtins.print = print_pass
    torch.backends.cudnn.benchmark = True
    torch.backends.cudnn.deterministic = True
    # torch.set_float32_matmul_precision("highest")
    # build the model
    model = Net().cuda()
    # model = torch.nn.SyncBatchNorm.convert_sync_batchnorm(model)

    # if opt.distributed:
    #     # For multiprocessing distributed, DistributedDataParallel constructor
    #     # should always set the single device scope, otherwise,
    #     # DistributedDataParallel will use all available devices.
    #     # os.system("nvidia-smi")
    #     if opt.gpu is not None:
    #         torch.cuda.set_device(opt.gpu)
    #         model.cuda(opt.gpu)
    #         model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[opt.gpu], find_unused_parameters=True)
    #         model_without_ddp = model.module
    #     else:
    #         model.cuda()
    #         model = torch.nn.parallel.DistributedDataParallel(model)
    #         model_without_ddp = model.module
    # else:
    #     raise NotImplementedError("Only DistributedDataParallel is supported.")

    # print(model)
    # model = torch.nn.DataParallel(model, device_ids=[0, 1])
    # r = torch.randn([1, 3, opt.trainsize, opt.trainsize]).cuda()
    # d = torch.randn([1, 3, opt.trainsize, opt.trainsize]).cuda()
    # params, flops = profile(model, inputs=(r, d))
    # flops, params = clever_format([flops, params], "%.2f")
    # print(flops, params)

    # if opt.load is not None:
    #     model.load_state_dict(torch.load(opt.load))
    #     print('load model from ', opt.load)

    optimizer = torch.optim.Adam(model.parameters(), opt.lr)
    save_path = opt.save_path
    if not os.path.exists(save_path):
        os.makedirs(save_path)

    # load data
    print('load data...')
    train_loader = get_loader(image_root=opt.train_root + 'Imgs/',
                              gt_root=opt.train_root + 'GT/',
                              depth_root=opt.train_root + 'Depth/',
                              batchsize=opt.batchsize,
                              trainsize=opt.trainsize)
    val_loader = test_dataset(image_root=opt.val_root + 'Imgs/',
                              depth_root=opt.val_root + 'Depth/',
                              gt_root=opt.val_root + 'GT/',
                              testsize=opt.trainsize)
    total_step = len(train_loader)

    # logging
    logging.basicConfig(filename=save_path + 'log.log',
                        format='[%(asctime)s-%(filename)s-%(levelname)s:%(message)s]',
                        level=logging.INFO, filemode='a', datefmt='%Y-%m-%d %I:%M:%S %p')
    logging.info('>>> model: {}'.format(model))
    logging.info(">>> current mode: network-train/val")
    logging.info('>>> config: {}'.format(opt))
    print('>>> config: : {}'.format(opt))

    step = 0
    writer = SummaryWriter(save_path + 'summary')

    best_mae = 1
    best_epoch = 0

    cosine_schedule = optim.lr_scheduler.CosineAnnealingLR(optimizer=optimizer, T_max=20, eta_min=1e-5)
    print(">>> start train...")
    for epoch in range(1, opt.epoch):
        # schedule
        cosine_schedule.step()
        writer.add_scalar('learning_rate', cosine_schedule.get_lr()[0], global_step=epoch)
        logging.info('>>> current lr: {}'.format(cosine_schedule.get_lr()[0]))
        # train
        train(train_loader, model, optimizer, epoch, save_path, )
        val(val_loader, model, epoch, save_path, )
