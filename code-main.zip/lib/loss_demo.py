"""
@File: loss_demo.py
@Time: 2024/5/30
@Author: rp
@Software: PyCharm

"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class CACLoss(nn.Module):
    def __init__(self, alpha=1.0, lambda_drw=1.0, eps=1e-8):
        """
        Contrast-Aware Camouflage Loss (CAC Loss) - 修正版本

        Args:
            alpha (float): 动态区域权重项的超参数，控制权重强度。
            lambda_drw (float): 动态区域权重项的权重，用于平衡对比度增强项和动态区域权重项。
            eps (float): 用于数值稳定性的小常数。
        """
        super(CACLoss, self).__init__()
        self.alpha = alpha
        self.lambda_drw = lambda_drw
        self.eps = eps

    def forward(self, pred, target):
        """
        计算修正后的 CAC Loss

        Args:
            pred (torch.Tensor): 模型的预测结果，形状为 (B, 1, H, W)，值范围为 [0, 1]。
            target (torch.Tensor): 真实标签，形状为 (B, 1, H, W)，值范围为 {0, 1}。

        Returns:
            torch.Tensor: 修正后的 CAC Loss 值。
        """
        # 确保 pred 和 target 的形状一致
        assert pred.shape == target.shape, "pred 和 target 的形状必须一致"

        # 对比度增强项 (修正后的 Contrast Enhancement Term)
        pred = torch.clamp(pred, self.eps, 1 - self.eps)  # 避免 log(0) 的情况
        contrast_ratio = pred / (1 - pred + self.eps)  # 计算对比度 p_i / (1 - p_i)
        l_ce = target * torch.abs(torch.log(contrast_ratio)) + (1 - target) * torch.abs(torch.log(1 / contrast_ratio))
        l_ce = l_ce.mean()  # 对所有像素取平均

        # 动态区域权重项 (Dynamic Region Weighting Term)
        diff = torch.abs(target - pred)  # 计算预测与真实标签的差异
        w_i = 1 + self.alpha * diff  # 动态权重
        l_drw = w_i * (target * (1 - pred)**2 + (1 - target) * pred**2)
        l_drw = l_drw.mean()  # 对所有像素取平均

        # 最终修正后的 CAC Loss
        loss = l_ce + self.lambda_drw * l_drw
        return loss


def cos_sim(embedded_fg, embedded_bg):
    embedded_fg = F.normalize(embedded_fg, dim=1)
    embedded_bg = F.normalize(embedded_bg, dim=1)
    sim = torch.matmul(embedded_fg, embedded_bg.T)

    return torch.clamp(sim, min=0.0005, max=0.9995)


def cos_distance(embedded_fg, embedded_bg):
    embedded_fg = F.normalize(embedded_fg, dim=1)
    embedded_bg = F.normalize(embedded_bg, dim=1)
    sim = torch.matmul(embedded_fg, embedded_bg.T)

    return 1 - sim


def l2_distance(embedded_fg, embedded_bg):
    N, C = embedded_fg.size()

    # embedded_fg = F.normalize(embedded_fg, dim=1)
    # embedded_bg = F.normalize(embedded_bg, dim=1)

    embedded_fg = embedded_fg.unsqueeze(1).expand(N, N, C)
    embedded_bg = embedded_bg.unsqueeze(0).expand(N, N, C)

    return torch.pow(embedded_fg - embedded_bg, 2).sum(2) / C


# Minimize Similarity, e.g., push representation of foreground and background apart.
class SimMinLoss(nn.Module):
    def __init__(self, margin=0.15, metric='cos', reduction='mean'):
        super(SimMinLoss, self).__init__()
        self.m = margin
        self.metric = metric
        self.reduction = reduction

    def forward(self, embedded_bg, embedded_fg):
        """
        :param embedded_fg: [N, C]
        :param embedded_bg: [N, C]
        :return:
        """
        if self.metric == 'l2':
            raise NotImplementedError
        elif self.metric == 'cos':
            sim = cos_sim(embedded_bg, embedded_fg)
            loss = -torch.log(1 - sim)
        else:
            raise NotImplementedError

        if self.reduction == 'mean':
            return torch.mean(loss)
        elif self.reduction == 'sum':
            return torch.sum(loss)


# Maximize Similarity, e.g., pull representation of background and background together.
class SimMaxLoss(nn.Module):
    def __init__(self, metric='cos', alpha=0.25, reduction='mean'):
        super(SimMaxLoss, self).__init__()
        self.metric = metric
        self.alpha = alpha
        self.reduction = reduction

    def forward(self, embedded_bg):
        """
        :param embedded_fg: [N, C]
        :param embedded_bg: [N, C]
        :return:
        """
        if self.metric == 'l2':
            raise NotImplementedError

        elif self.metric == 'cos':
            sim = cos_sim(embedded_bg, embedded_bg)
            loss = -torch.log(sim)
            loss[loss < 0] = 0
            _, indices = sim.sort(descending=True, dim=1)
            _, rank = indices.sort(dim=1)
            rank = rank - 1
            rank_weights = torch.exp(-rank.float() * self.alpha)
            loss = loss * rank_weights
        else:
            raise NotImplementedError

        if self.reduction == 'mean':
            return torch.mean(loss)
        elif self.reduction == 'sum':
            return torch.sum(loss)
        else:
            return loss


class Disentangler(nn.Module):
    def __init__(self, cin):
        super(Disentangler, self).__init__()

        self.activation_head = nn.Conv2d(cin, 1, kernel_size=3, padding=1, bias=False)
        self.bn_head = nn.BatchNorm2d(1)

    def forward(self, x):
        N, C, H, W = x.size()
        ccam = torch.sigmoid(self.bn_head(self.activation_head(x)))

        ccam_ = ccam.reshape(N, 1, H * W)  # [N, 1, H*W]
        x = x.reshape(N, C, H * W).permute(0, 2, 1).contiguous()  # [N, H*W, C]
        fg_feats = torch.matmul(ccam_, x) / (H * W)  # [N, 1, C]
        bg_feats = torch.matmul(1 - ccam_, x) / (H * W)  # [N, 1, C]

        return fg_feats.reshape(x.size(0), -1), bg_feats.reshape(x.size(0), -1), ccam


class SCLoss(nn.Module):
    def __init__(self, alpha=1):
        super(SCLoss, self).__init__()
        self.alpha = alpha

    def mutual_response(self, p_i, p_j, n_i, n_j):
        return n_i * n_j * torch.log(p_i * p_j) + (1 - n_i * n_j) * torch.log(1 - p_i * p_j)

    def forward(self, preds, targets):
        batch_size = preds.shape[0]
        total_loss = 0
        for b in range(batch_size):
            pred = preds[b]
            target = targets[b]
            height, width = target.shape[-2:]
            # 计算不同邻接级别下的损失
            for k in range(1, 3):  # 这里按照论文默认选择K=2，可以根据需要调整
                sub_loss = 0
                for i in range(height):
                    for j in range(width):
                        # 当前像素
                        p_i = pred[..., i, j]
                        n_i = target[..., i, j]
                        # 计算当前像素与邻接像素的损失
                        for di in range(-k, k + 1):
                            for dj in range(-k, k + 1):
                                if 0 <= i + di < height and 0 <= j + dj < width:
                                    p_j = pred[..., i + di, j + dj]
                                    n_j = target[..., i + di, j + dj]
                                    mutual_resp = self.mutual_response(p_i, p_j, n_i, n_j)
                                    weight = 1 / (mutual_resp + 1e-8)  # 避免除零
                                    pairwise_reg = torch.exp(-p_i * p_j)
                                    sub_loss += (n_i * torch.log(p_i) + (1 - n_i) * torch.log(1 - p_i)) / (
                                                mutual_resp + self.alpha * pairwise_reg)
                total_loss += sub_loss
        return total_loss / batch_size


# class WeightedBCEDiceIoULoss(nn.Module):
#     def __init__(self, pos_weight=None):
#         super(WeightedBCEDiceIoULoss, self).__init__()
#         self.pos_weight = pos_weight
#
#     def forward(self, inputs, targets, smooth=1):
#         # Flatten the input and target tensors
#         inputs = inputs.view(-1)
#         targets = targets.view(-1)
#
#         # Compute Weighted Binary Cross-Entropy Loss
#         if self.pos_weight is not None:
#             pos_weight = torch.tensor([self.pos_weight], dtype=inputs.dtype, device=inputs.device)
#             bce_loss = F.binary_cross_entropy_with_logits(inputs, targets, pos_weight=pos_weight)
#         else:
#             bce_loss = F.binary_cross_entropy_with_logits(inputs, targets)
#
#         # Apply sigmoid to inputs to get probabilities
#         inputs = torch.sigmoid(inputs)
#
#         # Compute Dice Loss
#         intersection = (inputs * targets).sum()
#         dice_loss = 1 - (2. * intersection + smooth) / (inputs.sum() + targets.sum() + smooth)
#
#         # Compute IoU Loss
#         intersection = (inputs * targets).sum()
#         total = (inputs + targets).sum()
#         union = total - intersection
#         iou_loss = 1 - (intersection + smooth) / (union + smooth)
#
#         # Combine the losses
#         loss = bce_loss + dice_loss + iou_loss
#
#         return loss


if __name__ == '__main__':
    # a = torch.randn([2, 1, 192])
    # b = torch.randn([2, 1, 192])
    # loss = SimMinLoss(metric='cos')
    # print(loss(a, b))
    x = torch.randn([2, 64, 48, 48])
    model = Disentangler(cin=64)
    re = model(x)
    print(re.shape)

# Example usage:
# criterion = WeightedBCEDiceIoULoss(pos_weight=3.0)
# loss = criterion(predictions, targets)


# class EnhancedWeightedBCEDiceIoULoss(nn.Module):
#     def __init__(self, pos_weight=None,alpha=1.0, beta=1.0, gamma=1.0, delta=1.0):
#         super(EnhancedWeightedBCEDiceIoULoss, self).__init__()
#         self.pos_weight = pos_weight
#         self.alpha = alpha
#         self.beta = beta
#         self.gamma = gamma
#         self.delta = delta
#
#     def forward(self, inputs, targets, smooth=1, ):
#         # Flatten the input and target tensors
#         inputs = inputs.view(-1)
#         targets = targets.view(-1)
#
#         # Compute Weighted Binary Cross-Entropy Loss
#         if self.pos_weight is not None:
#             pos_weight = torch.tensor([self.pos_weight], dtype=inputs.dtype, device=inputs.device)
#             bce_loss = F.binary_cross_entropy_with_logits(inputs, targets, pos_weight=pos_weight)
#         else:
#             bce_loss = F.binary_cross_entropy_with_logits(inputs, targets)
#
#         # Apply sigmoid to inputs to get probabilities
#         inputs = torch.sigmoid(inputs)
#
#         # Compute Dice Loss
#         intersection = (inputs * targets).sum()
#         dice_loss = 1 - (2. * intersection + smooth) / (inputs.sum() + targets.sum() + smooth)
#
#         # Compute IoU Loss
#         intersection = (inputs * targets).sum()
#         total = (inputs + targets).sum()
#         union = total - intersection
#         iou_loss = 1 - (intersection + smooth) / (union + smooth)
#
#         # Compute Boundary Loss
#         inputs_grad = torch.abs(torch.gradient(inputs)[0]) + torch.abs(torch.gradient(inputs)[1])
#         targets_grad = torch.abs(torch.gradient(targets)[0]) + torch.abs(torch.gradient(targets)[1])
#         boundary_loss = torch.mean(torch.abs(inputs_grad - targets_grad))
#
#         # Combine the losses
#         loss = self.alpha * bce_loss + self.beta * dice_loss + self.gamma * iou_loss + self.delta * boundary_loss
#
#         return loss
# Example usage:
# criterion = EnhancedWeightedBCEDiceIoULoss(pos_weight=2.0, alpha=1.0, beta=1.0, gamma=1.0, delta=0.5)
# loss = criterion(predictions, targets)


# class EnhancedSaliencyLoss(nn.Module):
#     def __init__(self, pos_weight=None, alpha=1.0, beta=1.0, gamma=1.0, delta=1.0, epsilon=1.0):
#         super(EnhancedSaliencyLoss, self).__init__()
#         self.pos_weight = pos_weight
#         self.alpha = alpha
#         self.beta = beta
#         self.gamma = gamma
#         self.delta = delta
#         self.epsilon = epsilon
#
#     def ssim(self, x, y, window_size=11, size_average=True):
#         def gaussian(window_size, sigma):
#             gauss = torch.Tensor([torch.exp((x - window_size // 2)**2 / (-2.0 * sigma**2)) for x in range(window_size)])
#             return gauss / gauss.sum()
#
#         def create_window(window_size, channel):
#             _1D_window = gaussian(window_size, 1.5).unsqueeze(1)
#             _2D_window = _1D_window.mm(_1D_window.t()).float().unsqueeze(0).unsqueeze(0)
#             window = _2D_window.expand(channel, 1, window_size, window_size).contiguous()
#             return window
#
#         channel = x.size(1)
#         window = create_window(window_size, channel).to(x.device)
#
#         mu1 = F.conv2d(x, window, padding=window_size // 2, groups=channel)
#         mu2 = F.conv2d(y, window, padding=window_size // 2, groups=channel)
#
#         mu1_sq = mu1.pow(2)
#         mu2_sq = mu2.pow(2)
#         mu1_mu2 = mu1 * mu2
#
#         sigma1_sq = F.conv2d(x * x, window, padding=window_size // 2, groups=channel) - mu1_sq
#         sigma2_sq = F.conv2d(y * y, window, padding=window_size // 2, groups=channel) - mu2_sq
#         sigma12 = F.conv2d(x * y, window, padding=window_size // 2, groups=channel) - mu1_mu2
#
#         C1 = 0.01 ** 2
#         C2 = 0.03 ** 2
#
#         ssim_map = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2)) / ((mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2))
#
#         if size_average:
#             return ssim_map.mean()
#         else:
#             return ssim_map.mean(1).mean(1).mean(1)
#
#     def forward(self, inputs, targets, smooth=1):
#         # Flatten the input and target tensors
#         inputs = inputs.view(-1)
#         targets = targets.view(-1)
#
#         # Compute Weighted Binary Cross-Entropy Loss
#         if self.pos_weight is not None:
#             pos_weight = torch.tensor([self.pos_weight], dtype=inputs.dtype, device=inputs.device)
#             bce_loss = F.binary_cross_entropy_with_logits(inputs, targets, pos_weight=pos_weight)
#         else:
#             bce_loss = F.binary_cross_entropy_with_logits(inputs, targets)
#
#         # Apply sigmoid to inputs to get probabilities
#         inputs = torch.sigmoid(inputs)
#
#         # Compute Dice Loss
#         intersection = (inputs * targets).sum()
#         dice_loss = 1 - (2. * intersection + smooth) / (inputs.sum() + targets.sum() + smooth)
#
#         # Compute IoU Loss
#         intersection = (inputs * targets).sum()
#         total = (inputs + targets).sum()
#         union = total - intersection
#         iou_loss = 1 - (intersection + smooth) / (union + smooth)
#
#         # Compute Boundary Loss using Sobel operator
#         sobel_filter = torch.tensor([[1, 2, 1], [0, 0, 0], [-1, -2, -1]], dtype=torch.float32, device=inputs.device).view(1, 1, 3, 3)
#         inputs_grad = F.conv2d(inputs.unsqueeze(0).unsqueeze(0), sobel_filter, padding=1).view(-1)
#         targets_grad = F.conv2d(targets.unsqueeze(0).unsqueeze(0), sobel_filter, padding=1).view(-1)
#         boundary_loss = torch.mean(torch.abs(inputs_grad - targets_grad))
#
#         # Compute SSIM Loss
#         inputs = inputs.view(1, 1, int(inputs.shape[0]**0.5), int(inputs.shape[0]**0.5))
#         targets = targets.view(1, 1, int(targets.shape[0]**0.5), int(targets.shape[0]**0.5))
#         ssim_loss = 1 - self.ssim(inputs, targets)
#
#         # Combine the losses
#         loss = self.alpha * bce_loss + self.beta * dice_loss + self.gamma * iou_loss + self.delta * boundary_loss + self.epsilon * ssim_loss
#
#         return loss
#
# # 使用示例
# # 创建损失函数实例
# loss_fn = EnhancedSaliencyLoss(pos_weight=2.0, alpha=1.0, beta=1.0, gamma=1.0, delta=1.0, epsilon=1.0)
#
# # 模型输出和真实标签
# inputs = torch.randn((1, 1, 256, 256))  # 模拟的模型输出
# targets = torch.randint(0, 2, (1, 1, 256, 256))  # 模拟的真实标签
#
# # 计算损失
# loss = loss_fn(inputs, targets)
# print(f'Loss: {loss.item()}')
#
#
#
