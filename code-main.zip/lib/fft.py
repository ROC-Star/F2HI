# @Time    : 2025/3/25 11:12
# @Author  : rp
# @File    : fft.py
# @Time    : 2025/3/25 11:00
# @Author  : rp
# @File    : fft.py
import torch
import torch.nn as nn
import torch.fft
from lib.modules import Block

class FrequencyDecomposition(nn.Module):
    """频域分解模块（可学习滤波器版本）"""

    def __init__(self, in_channels, filter_size=3):
        super().__init__()
       
        self.low_filter = nn.Conv2d(in_channels, in_channels, filter_size,
                                    padding=filter_size // 2, groups=in_channels, bias=False)
        self.high_filter = nn.Conv2d(in_channels, in_channels, filter_size,

                                     padding=filter_size // 2, groups=in_channels, bias=False)

        
        self._init_filters(filter_size)

    def _init_filters(self, size):
        
        gaussian = torch.randn(size, size) * 0.1
        self.low_filter.weight.data = gaussian.view(1, 1, size, size).repeat(self.low_filter.in_channels, 1, 1, 1)
        self.high_filter.weight.data = -gaussian.view(1, 1, size, size).repeat(self.high_filter.in_channels, 1, 1, 1)
        self.high_filter.weight.data[:, :, size // 2, size // 2] += 1  # 中心点增强

    def forward(self, x):
        
        fft_feat = torch.fft.rfft2(x, norm='ortho')

        
        low_part = self.low_filter(x)
        high_part = self.high_filter(x)

        return {
            'fft': fft_feat,  
            'low': low_part,  
            'high': high_part  
        }


class CrossModalFrequencyAttention(nn.Module):
    

    def __init__(self, channels, reduction=4):
        super().__init__()
        self.query_conv = nn.Conv2d(channels, channels // reduction, 1)
        self.key_conv = nn.Conv2d(channels, channels // reduction, 1)
        self.value_conv = nn.Conv2d(channels, channels, 1)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, rgb_feat, depth_feat):
       
        batch_size, C, H, W = rgb_feat.size()

        
        query = self.query_conv(rgb_feat).view(batch_size, -1, H * W).permute(0, 2, 1)  # [B, N, C']
        key = self.key_conv(depth_feat).view(batch_size, -1, H * W)  # [B, C', N]

        
        energy = torch.bmm(query, key)  # [B, N, N]
        attention = self.softmax(energy)

        
        value = self.value_conv(depth_feat).view(batch_size, -1, H * W)  # [B, C, N]
        out = torch.bmm(value, attention.permute(0, 2, 1))  # [B, C, N]
        out = out.view(batch_size, C, H, W)

        return out  


class FHIFModule(nn.Module):
    

    def __init__(self, dim, filter_size=3):
        super().__init__()
       
        self.rgb_freq = FrequencyDecomposition(dim, filter_size)
        self.depth_freq = FrequencyDecomposition(dim, filter_size)

      
        self.rgb2depth_attn = CrossModalFrequencyAttention(dim)
        self.depth2rgb_attn = CrossModalFrequencyAttention(dim)

       
        self.dynamic_filter = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim * 2, dim // 2, 1),
            nn.ReLU(),
            nn.Conv2d(dim // 2, dim * 2, 1),
            nn.Sigmoid()
        )

       
        self.gate_conv = nn.Sequential(
            nn.Conv2d(dim * 2, 1, 1),
            nn.Sigmoid()
        )
        self.block = Block(dim=dim)

    def forward(self, rgb_feat, depth_feat):
      
        rgb_freq = self.rgb_freq(rgb_feat)
        depth_freq = self.depth_freq(depth_feat)

      
        depth_low_aug = self.rgb2depth_attn(rgb_freq['high'], depth_freq['low'])
        
        rgb_high_aug = self.depth2rgb_attn(depth_freq['low'], rgb_freq['high'])

       
        combined = torch.cat([rgb_high_aug, depth_low_aug], dim=1)
        mask = self.dynamic_filter(combined)
        mask_rgb, mask_depth = torch.chunk(mask, 2, dim=1)

        fused_freq = mask_rgb * rgb_high_aug + mask_depth * depth_low_aug

        
        fused_spatial = torch.fft.irfft2(fused_freq, s=rgb_feat.shape[-2:], norm='ortho')


        gate = self.gate_conv(torch.cat([fused_spatial, rgb_feat], dim=1))
        final_out = gate * fused_spatial + (1 - gate) * rgb_feat
        final_out = self.block(final_out)

        return final_out



if __name__ == "__main__":
    rgb_feat = torch.randn(2, 64, 96, 96)
    depth_feat = torch.randn(2, 64, 96, 96)

    fhifm = FHIFModule(channels=64)
    output = fhifm(rgb_feat, depth_feat)
    print(output.shape) 