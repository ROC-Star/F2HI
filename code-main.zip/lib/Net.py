"""
@File: Net.py
@Time: 2023/11/30
@Author: rp
@Software: PyCharm

"""
import torch
import torch.nn.functional as F
from fvcore.nn import FlopCountAnalysis, flop_count_table

from thop import profile, clever_format
from torch import nn as nn

from lib.EMO2 import EMO2_5M_k5_hybrid_512
# from lib.Freefusion import FreqFusion
from lib.SMT import smt_t, smt_b
from lib.modules import Depth_Backbone, DimensionalReduction, LightDecoder, MaskGuidance, Block, Refine, MFFM, CTM
from lib.module_demo import FeatureFusion
# from lib.Transnext import transnext_small
from lib.Demo import MogaBlock
# from lib.overlock import overlock_t
from lib.HGINet import HGIT
from lib.MobileNetV2 import mobilenet_v2
from lib.Fused_Conv_Mixer import Fused_Fourier_Conv_Mixer
from lib.attention import BiLevelRoutingAttention_nchw


class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()

        self.encoder = smt_b(pretrained=False)
        # self.encoder = overlock_t(pretrained=True)
        # self.depth_encoder = Depth_Backbone()
        self.depth_encoder = mobilenet_v2(pretrained=False)
        # self.depth_encoder = EMO2_5M_k5_hybrid_512()
        # self.depth_encoder = transnext_small(pretrained=True)
        self.hid_dim = 64
        channel_list = [64, 128, 256, 512]

        self.dr = DimensionalReduction(channel_list[0], self.hid_dim)
        self.dr1 = DimensionalReduction(channel_list[1], self.hid_dim)
        self.dr2 = DimensionalReduction(channel_list[2], self.hid_dim)
        self.dr3 = DimensionalReduction(channel_list[3], self.hid_dim)

        # self.d_trans_4 = DimensionalReduction(320, self.hid_dim)
        self.d_trans_4 = DimensionalReduction(320, self.hid_dim)
        self.d_trans_3 = DimensionalReduction(96, 64)
        self.d_trans_2 = DimensionalReduction(32, 64)
        self.d_trans_1 = DimensionalReduction(24, 64)


        # self.d_trans_3 = DimensionalReduction(96, 64)
        # self.d_trans_2 = DimensionalReduction(32, 64)
        # self.d_trans_1 = DimensionalReduction(24, 64)
        # self.d_trans_3 = DimensionalReduction(288, self.hid_dim)
        # self.d_trans_2 = DimensionalReduction(160, self.hid_dim)
        # self.d_trans_1 = DimensionalReduction(72, self.hid_dim)
        # self.d_trans = DimensionalReduction(48, self.hid_dim)
        self.dr4 = DimensionalReduction(128, self.hid_dim)
        # self.trans = nn.Conv2d(in_channels=512, out_channels=128, kernel_size=3, padding=1)
        # self.trans1 = nn.Conv2d(in_channels=512, out_channels=256, kernel_size=3, padding=1)
        # self.trans = DimensionalReduction(512, 128)

        # self.fusion1 = MFFM(dim=64)
        # self.fusion2 = MFFM(dim=64)
        # self.fusion3 = MFFM(dim=64)
        # self.fusion4 = MFFM(dim=64)
        self.fusion1 = FeatureFusion(dim=self.hid_dim)
        self.fusion2 = FeatureFusion(dim=self.hid_dim)
        self.fusion3 = FeatureFusion(dim=self.hid_dim)
        self.fusion4 = FeatureFusion(dim=self.hid_dim)

        # self.fusion1 = CGAFusion(dim=64)
        # self.fusion2 = CGAFusion(dim=64)
        # self.fusion3 = CGAFusion(dim=64)
        # self.fusion4 = CGAFusion(dim=64)

        # self.lightdecoder = LightDecoder(channel=64)
        # self.refine = Refine()
        self.up2 = nn.UpsamplingBilinear2d(scale_factor=2)
        self.up4 = nn.UpsamplingBilinear2d(scale_factor=4)
        self.up8 = nn.UpsamplingBilinear2d(scale_factor=8)
        self.up16 = nn.UpsamplingBilinear2d(scale_factor=16)
        self.up32 = nn.UpsamplingBilinear2d(scale_factor=32)

        # self.mg = MaskGuidance(channel=64, group_num=32)
        # self.mg1 = MaskGuidance(channel=64, group_num=32)
        # self.mg2 = MaskGuidance(channel=64, group_num=32)
        # self.mg3 = MaskGuidance(channel=64, group_num=32)
        # self.block1 = HGIT(dim=self.hid_dim)
        # self.block2 = HGIT(dim=self.hid_dim)
        # self.block3 = HGIT(dim=self.hid_dim)

        self.block1 = MogaBlock(embed_dims=self.hid_dim)
        self.block2 = MogaBlock(embed_dims=self.hid_dim)
        self.block3 = MogaBlock(embed_dims=self.hid_dim)
        # self.attn1 = BiLevelRoutingAttention_nchw(64)
        # self.attn2 = BiLevelRoutingAttention_nchw(64)
        # self.attn3 = BiLevelRoutingAttention_nchw(64)
        # self.block = Fused_Fourier_Conv_Mixer(dim=64)
        # self.cmiu1 = CMIU(in_dim=64, embed_dim=64, nh=2, p=8, ffn_expand=1)
        # self.cmiu2 = CMIU(in_dim=64, embed_dim=64, nh=2, p=8, ffn_expand=1)
        # self.cmiu3 = CMIU(in_dim=64, embed_dim=64, nh=2, p=8, ffn_expand=1)
        # self.cmiu4 = CMIU(in_dim=64, embed_dim=64, nh=2, p=8, ffn_expand=1)

        # self.block1 = OutlookAttention(dim=128, num_heads=8)
        # self.block2 = OutlookAttention(dim=192, num_heads=8)
        # self.block3 = OutlookAttention(dim=256, num_heads=8)
        # self.ff1 = FreqFusion(hr_channels=64, lr_channels=64)
        # self.ff2 = FreqFusion(hr_channels=64, lr_channels=128)
        # self.ff3 = FreqFusion(hr_channels=64, lr_channels=192)

        self.salhead1 = nn.Conv2d(in_channels=64, out_channels=1, kernel_size=3, padding=1)
        self.salhead2 = nn.Conv2d(in_channels=64, out_channels=1, kernel_size=3, padding=1)
        # self.salhead3 = nn.Conv2d(in_channels=192, out_channels=1, kernel_size=3, padding=1)
        self.salhead4 = nn.Conv2d(in_channels=64, out_channels=1, kernel_size=3, padding=1)
        self.salhead5 = nn.Conv2d(in_channels=64, out_channels=1, kernel_size=3, padding=1)
        self.ctm1 = CTM(channel_list[0], 64, 0.25)
        self.ctm2 = CTM(channel_list[1], 64, 0.25)
        self.ctm3 = CTM(channel_list[2], 64, 0.25)
        self.ctm4 = CTM(channel_list[3], 64, 0.25)

    def vison_token_agg(self, last_image_deep):
        B, C, H, W = last_image_deep.shape
        vision = last_image_deep.reshape(B, C, H * W).transpose(1, 2)
        B, N, _ = vision.shape
        device = vision.device
        idx_token = torch.arange(N)[None, :].repeat(B, 1).to(device)
        agg_weight = vision.new_ones(B, N, 1)
        token_dict = {'x': vision,
                      'token_num': N,
                      'map_size': [H, W],
                      'init_grid_size': [H, W],
                      'idx_token': idx_token,
                      'agg_weight': agg_weight}
        # last_vision_map_new = self.ctm4(token_dict)
        return token_dict

    def forward(self, r, d):
        rgb = self.encoder(r)
        d = self.depth_encoder(d)

        # rgb1 = self.dr(rgb[0])
        # rgb2 = self.dr1(rgb[1])
        # rgb3 = self.dr2(rgb[2])
        # rgb4 = self.dr3(rgb[3])
        rgb1_token_dict = self.vison_token_agg(rgb[0])
        rgb1 = self.ctm1(rgb1_token_dict)
        rgb2_token_dict = self.vison_token_agg(rgb[1])
        rgb2 = self.ctm2(rgb2_token_dict)
        rgb3_token_dict = self.vison_token_agg(rgb[2])
        rgb3 = self.ctm3(rgb3_token_dict)
        rgb4_token_dict = self.vison_token_agg(rgb[3])
        rgb4 = self.ctm4(rgb4_token_dict)

        d1 = self.d_trans_1(d[1])
        d2 = self.d_trans_2(d[2])
        d3 = self.d_trans_3(d[3])
        d4 = self.d_trans_4(d[4])
        # d1 = self.d_trans(d[0])
        # d2 = self.d_trans_1(d[1])
        # d3 = self.d_trans_2(d[2])
        # d4 = self.d_trans_3(d[3])

        f1 = self.fusion1(rgb1, d1)  #[1,64,56,56]
        f2 = self.fusion2(rgb2, d2)  #[1,64,28,28]
        f3 = self.fusion3(rgb3, d3)  #[1,64,14,14]
        f4 = self.fusion4(rgb4, d4)  #[1,64,7,7]

        f4_2 = self.up4(f4)  #[1,64,28,28]
        f4_1 = self.up8(f4)  #[1,64,56,56]
        f3_1 = self.up4(f3)  #[1,64,56,56]

        # _, hr, f4_3 = self.ff1(hr_feat=f3, lr_feat=f4)  # [1,64,14,14]
        f4_3 = self.dr1(torch.cat([self.up2(f4), f3], dim=1))  # [b,128,14,14] ->64
        f4_3 = self.block1(f4_3)  # [b,128,14,14] 64
        # f4_3 = self.attn1(f4_3)

        f4_2 = self.dr1(torch.cat([f4_2, f2], dim=1))  # [b,128,28,28]
        # _, hr, f4_3_2 = self.ff1(hr_feat=f4_2, lr_feat=f4_3)
        f4_3_2 = self.dr4(torch.cat([self.up2(f4_3), f4_2], dim=1))  # [b,256,28,28] ->64
        f4_3_2 = self.block2(f4_3_2)  # [b,256,28,28]
        # f4_3_2 = self.attn2(f4_3_2)
        f4_1 = torch.cat([f4_1, f1], dim=1)  # [b,128,56,56]
        f3_1 = torch.cat([f3_1, f1], dim=1)  # [b,128,56,56]
        f4_3_2_1 = self.d_trans_4(torch.cat([self.up2(f4_3_2), f4_1, f3_1], dim=1))  # [b,512,56,56] ->64
        f4_3_2_1 = self.block3(f4_3_2_1)  # [b,256,56,56]
        # f4_3_2_1 = self.attn1(f4_3_2_1)
        # segmap = f4_3_2_1
        s4 = self.salhead1(self.up32(f4))
        s3 = self.salhead2(self.up16(f4_3))
        s2 = self.salhead4(self.up8(f4_3_2))
        s1 = self.salhead5(self.up4(f4_3_2_1))
        x = self.up4(f4_3_2_1)

        init_sal_map = s1
        ###################构造对比学习==============
        N, C, H, W = x.size()
        cam = torch.sigmoid(init_sal_map)

        cam_ = cam.reshape(N, 1, H * W)  # [N, 1, H*W]
        x = x.reshape(N, C, H * W).permute(0, 2, 1).contiguous()  # [N, H*W, C]
        fg_feats = torch.matmul(cam_, x) / (H * W)  # [N, 1, C]
        bg_feats = torch.matmul(1 - cam_, x) / (H * W)  # [N, 1, C]
        fg = fg_feats.reshape(x.size(0), -1)
        bg = bg_feats.reshape(x.size(0), -1)

        return s1, s2, s3, s4, fg, bg

        # return s4, s3, s2, s1

        # fg, bg, init_pred = self.lightdecoder(f4, f3, f2)
        # init_pred1 = self.up8(init_pred)  # 粗略显著图
        #
        # f4_3 = F.interpolate(f4, size=f3.size()[2:], mode='bilinear', align_corners=True)
        # f3_2 = F.interpolate(f3, size=f2.size()[2:], mode='bilinear', align_corners=True)
        # f2_1 = F.interpolate(f2, size=f1.size()[2:], mode='bilinear', align_corners=True)
        # f1_m = self.mg((f2_1 + f1), init_pred)
        # f2_m = self.mg1((f3_2 + f2), init_pred)  # [1,64,44,44]
        # f3_m = self.mg2((f4_3 + f3), init_pred)  # [1,64,22,22]
        # # f4_m = self.mg3(f4, init_pred)# [1,64,11,11]
        # f4_m = self.refine(init_pred, f4)
        #
        # f4_m_pred = self.salhead1(self.up32(f4_m))  # [1,1,352,352]
        # _, _, f4_m_up = self.ff1(f3_m, f4_m) #先初步融合然后在拼接
        # # f4_3_m = torch.cat([f3_m, self.up2(f4_m)], dim=1)  # [1,128,22,22]
        # f4_3_m = torch.cat([f3_m, f4_m_up], dim=1)
        # f4_3_m = self.block1(f4_3_m)
        # f4_3_m_pred = self.salhead2(self.up16(f4_3_m))  # [1,1, 352,352]
        #
        # _,_,f4_3_m_up = self.ff2(f2_m, f4_3_m)
        # # f4_3_2_m = torch.cat([f2_m, self.up2(f4_3_m)], dim=1)  # [1,192,44,44]
        # f4_3_2_m = torch.cat([f2_m, f4_3_m_up], dim=1)
        # f4_3_2_m = self.block2(f4_3_2_m)
        # f4_3_2_m_pred = self.salhead3(self.up8(f4_3_2_m))  # [1,1, 352,352]
        # _,_,f4_3_2_m_up = self.ff3(f1_m, f4_3_2_m)
        # # f4_3_2_1_m = torch.cat([f1_m, self.up2(f4_3_2_m)], dim=1)  # [1,256,88,88]
        # f4_3_2_1_m = torch.cat([f1_m, f4_3_2_m_up], dim=1)
        # f4_3_2_1_m = self.block3(f4_3_2_1_m)
        # f4_3_2_1_m_pred = self.salhead4(self.up4(f4_3_2_1_m))

        # return f4_3_2_1_m_pred, f4_3_2_m_pred, f4_3_m_pred, f4_m_pred, init_pred1, fg,bg


if __name__ == '__main__':
    model = Net()
    r = torch.randn([1, 3, 384, 384])
    d = torch.randn([1, 3, 384, 384])
    re1,re2,re3,re4,fg,bg = model(r, d)
    print(re1.shape)


