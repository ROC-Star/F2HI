# @Time    : 2024/10/5 11:30
# @Author  : rp
# @File    : Demo.py

import torch.nn as nn
import torch
from einops import rearrange, repeat, reduce
from einops.layers.torch import Rearrange
import torch.nn.functional as F
import math
from timm.layers import DropPath


class PreNorm(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(self.norm(x), **kwargs)


def MaskAveragePooling(x, mask):
    mask = torch.sigmoid(mask)
    b, c, h, w = x.shape
    eps = 0.0005
    x_mask = x * mask
    h, w = x.shape[2], x.shape[3]
    area = F.avg_pool2d(mask, (h, w)) * h * w + eps
    x_feat = F.avg_pool2d(x_mask, (h, w)) * h * w / area
    x_feat = x_feat.view(b, c, -1)
    return x_feat


class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim, dropout=0.):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        return self.net(x)


# Lesion-aware Cross Attention
class LCA_layer(nn.Module):
    def __init__(self, dim, heads=8, dim_head=64, dropout=0.):
        super().__init__()
        inner_dim = dim_head * heads
        project_out = not (heads == 1 and dim_head == dim)
        self.heads = heads
        self.scale = dim_head ** -0.5

        self.attend = nn.Softmax(dim=-1)
        self.to_qkv = nn.Conv2d(dim, inner_dim * 3, kernel_size=1, stride=1, padding=0, bias=False)
        self.to_out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout)
        ) if project_out else nn.Identity()

    def forward(self, x, mask):
        # input x (b, c, h, w)
        # if x.size != mask.size:
        #     mask = F.interpolate(mask, size=x.size()[2:], mode='bilinear', align_corners=False)
        b, c, h, w = x.shape
        q, k, v = self.to_qkv(x).chunk(3, dim=1)  # q/k/v shape: (b, inner_dim, h, w)
        q = rearrange(q, 'b (head d) h w -> b head (h w) d', head=self.heads)  # q shape: (b, head, n_q, d)

        k, v = MaskAveragePooling(k, mask), MaskAveragePooling(v, mask)  # k/v shape: (b, inner_dim, 1)
        k = rearrange(k, 'b (head d) n -> b head n d', head=self.heads)  # k shape: (b, head, 1, d)
        v = rearrange(v, 'b (head d) n -> b head n d', head=self.heads)  # v shape: (b, head, 1, d)

        dots = torch.matmul(q, k.transpose(-1, -2)) * self.scale  # shape: (b, head, n_q, n_kv)

        attn = self.attend(dots)

        out = torch.matmul(attn, v)  # shape: (b, head, n_q, d)
        out = rearrange(out, 'b head n d -> b n (head d)')
        return self.to_out(out)


class LCA_blcok(nn.Module):
    def __init__(self, dim, heads=8, dim_head=64, mlp_dim=512, dropout=0.):
        super().__init__()
        self.LCAlayer = LCA_layer(dim, heads=heads, dim_head=dim_head, dropout=dropout)
        self.ff = PreNorm(dim, FeedForward(dim, mlp_dim, dropout=dropout))

    def forward(self, x, mask):
        b, c, h, w = x.shape
        out = rearrange(x, 'b c h w -> b (h w) c')
        out = self.LCAlayer(x, mask) + out
        out = self.ff(out) + out
        out = rearrange(out, 'b (h w) c -> b c h w', h=h)

        return out


def normal_init(module, mean=0, std=1, bias=0):
    if hasattr(module, 'weight') and module.weight is not None:
        nn.init.normal_(module.weight, mean, std)
    if hasattr(module, 'bias') and module.bias is not None:
        nn.init.constant_(module.bias, bias)


def constant_init(module, val, bias=0):
    if hasattr(module, 'weight') and module.weight is not None:
        nn.init.constant_(module.weight, val)
    if hasattr(module, 'bias') and module.bias is not None:
        nn.init.constant_(module.bias, bias)


class DySample(nn.Module):
    def __init__(self, in_channels, scale=2, style='lp', groups=4, dyscope=False):
        super().__init__()
        self.scale = scale
        self.style = style
        self.groups = groups
        assert style in ['lp', 'pl']
        if style == 'pl':
            assert in_channels >= scale ** 2 and in_channels % scale ** 2 == 0
        assert in_channels >= groups and in_channels % groups == 0

        if style == 'pl':
            in_channels = in_channels // scale ** 2
            out_channels = 2 * groups
        else:
            out_channels = 2 * groups * scale ** 2

        self.offset = nn.Conv2d(in_channels, out_channels, 1)
        normal_init(self.offset, std=0.001)
        if dyscope:
            self.scope = nn.Conv2d(in_channels, out_channels, 1, bias=False)
            constant_init(self.scope, val=0.)

        self.register_buffer('init_pos', self._init_pos())

    def _init_pos(self):
        h = torch.arange((-self.scale + 1) / 2, (self.scale - 1) / 2 + 1) / self.scale
        return torch.stack(torch.meshgrid([h, h])).transpose(1, 2).repeat(1, self.groups, 1).reshape(1, -1, 1, 1)

    def sample(self, x, offset):
        B, _, H, W = offset.shape
        offset = offset.view(B, 2, -1, H, W)
        coords_h = torch.arange(H) + 0.5
        coords_w = torch.arange(W) + 0.5
        coords = torch.stack(torch.meshgrid([coords_w, coords_h])
                             ).transpose(1, 2).unsqueeze(1).unsqueeze(0).type(x.dtype).to(x.device)
        normalizer = torch.tensor([W, H], dtype=x.dtype, device=x.device).view(1, 2, 1, 1, 1)
        coords = 2 * (coords + offset) / normalizer - 1
        coords = F.pixel_shuffle(coords.view(B, -1, H, W), self.scale).view(
            B, 2, -1, self.scale * H, self.scale * W).permute(0, 2, 3, 4, 1).contiguous().flatten(0, 1)
        return F.grid_sample(x.reshape(B * self.groups, -1, H, W), coords, mode='bilinear',
                             align_corners=False, padding_mode="border").view(B, -1, self.scale * H, self.scale * W)

    def forward_lp(self, x):
        if hasattr(self, 'scope'):
            offset = self.offset(x) * self.scope(x).sigmoid() * 0.5 + self.init_pos
        else:
            offset = self.offset(x) * 0.25 + self.init_pos
        return self.sample(x, offset)

    def forward_pl(self, x):
        x_ = F.pixel_shuffle(x, self.scale)
        if hasattr(self, 'scope'):
            offset = F.pixel_unshuffle(self.offset(x_) * self.scope(x_).sigmoid(), self.scale) * 0.5 + self.init_pos
        else:
            offset = F.pixel_unshuffle(self.offset(x_), self.scale) * 0.25 + self.init_pos
        return self.sample(x, offset)

    def forward(self, x):
        if self.style == 'pl':
            return self.forward_pl(x)
        return self.forward_lp(x)


class SpatialAttention(nn.Module):
    def __init__(self):
        super(SpatialAttention, self).__init__()
        self.sa = nn.Conv2d(2, 1, 7, padding=3, padding_mode='reflect', bias=True)

    def forward(self, x):
        x_avg = torch.mean(x, dim=1, keepdim=True)
        x_max, _ = torch.max(x, dim=1, keepdim=True)
        x2 = torch.cat([x_avg, x_max], dim=1)
        sattn = self.sa(x2)
        return sattn


class ChannelAttention(nn.Module):
    def __init__(self, dim, reduction=8):
        super(ChannelAttention, self).__init__()
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.ca = nn.Sequential(
            nn.Conv2d(dim, dim // reduction, 1, padding=0, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(dim // reduction, dim, 1, padding=0, bias=True),
        )

    def forward(self, x):
        x_gap = self.gap(x)
        cattn = self.ca(x_gap)
        return cattn


class PixelAttention(nn.Module):
    def __init__(self, dim):
        super(PixelAttention, self).__init__()
        self.pa2 = nn.Conv2d(2 * dim, dim, 7, padding=3, padding_mode='reflect', groups=dim, bias=True)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x, pattn1):
        B, C, H, W = x.shape
        x = x.unsqueeze(dim=2)  # B, C, 1, H, W
        pattn1 = pattn1.unsqueeze(dim=2)  # B, C, 1, H, W
        x2 = torch.cat([x, pattn1], dim=2)  # B, C, 2, H, W
        x2 = Rearrange('b c t h w -> b (c t) h w')(x2)
        pattn2 = self.pa2(x2)
        pattn2 = self.sigmoid(pattn2)
        return pattn2


class CGAFusion(nn.Module):
    def __init__(self, dim, reduction=8):
        super(CGAFusion, self).__init__()
        self.sa = SpatialAttention()
        self.ca = ChannelAttention(dim, reduction)
        self.pa = PixelAttention(dim)
        self.conv = nn.Conv2d(dim, dim, 1, bias=True)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x, y):
        initial = x + y
        cattn = self.ca(initial)
        sattn = self.sa(initial)
        pattn1 = sattn + cattn
        pattn2 = self.sigmoid(self.pa(initial, pattn1))
        result = initial + pattn2 * x + (1 - pattn2) * y
        result = self.conv(result)
        return result


class OutlookAttention(nn.Module):
    """
    Implementation of outlook attention
    --dim: hidden dim
    --num_heads: number of heads
    --kernel_size: kernel size in each window for outlook attention
    return: token features after outlook attention
    """

    def __init__(self, dim, num_heads, kernel_size=3, padding=1, stride=1,
                 qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.):
        super().__init__()
        head_dim = dim // num_heads
        self.num_heads = num_heads
        self.kernel_size = kernel_size
        self.padding = padding
        self.stride = stride
        self.scale = qk_scale or head_dim ** -0.5

        self.v = nn.Linear(dim, dim, bias=qkv_bias)
        self.attn = nn.Linear(dim, kernel_size ** 4 * num_heads)

        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

        self.unfold = nn.Unfold(kernel_size=kernel_size, padding=padding, stride=stride)
        self.pool = nn.AvgPool2d(kernel_size=stride, stride=stride, ceil_mode=True)

    def forward(self, x):
        x = x.permute(0, 2, 3, 1)

        B, H, W, C = x.shape

        v = self.v(x).permute(0, 3, 1, 2)  # B, C, H, W

        h, w = math.ceil(H / self.stride), math.ceil(W / self.stride)
        v = self.unfold(v).reshape(B, self.num_heads, C // self.num_heads,
                                   self.kernel_size * self.kernel_size,
                                   h * w).permute(0, 1, 4, 3, 2)  # B,H,N,kxk,C/H

        attn = self.pool(x.permute(0, 3, 1, 2)).permute(0, 2, 3, 1)
        attn = self.attn(attn).reshape(
            B, h * w, self.num_heads, self.kernel_size * self.kernel_size,
               self.kernel_size * self.kernel_size).permute(0, 2, 1, 3, 4)  # B,H,N,kxk,kxk
        attn = attn * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        x = (attn @ v).permute(0, 1, 4, 3, 2).reshape(
            B, C * self.kernel_size * self.kernel_size, h * w)
        x = F.fold(x, output_size=(H, W), kernel_size=self.kernel_size,
                   padding=self.padding, stride=self.stride)

        x = self.proj(x.permute(0, 2, 3, 1))
        x = self.proj_drop(x).permute(0, 3, 1, 2)

        return x


class MFFM(nn.Module):
    def __init__(self, dim):
        super(MFFM, self).__init__()
        self.gmp_RGB = nn.Sequential(
            nn.AdaptiveMaxPool2d(1),
            nn.Conv2d(dim, dim, 1, padding=0),
            nn.ReLU(inplace=True),
            nn.Sigmoid()
        )
        self.gmp_Depth = nn.Sequential(
            nn.AdaptiveMaxPool2d(1),
            nn.Conv2d(dim, dim, 1, padding=0),
            nn.ReLU(inplace=True),
            nn.Sigmoid()
        )
        self.conv1 = nn.Conv2d(dim * 2, dim, kernel_size=3, padding=1)
        # self.max_pool = nn.AdaptiveMaxPool2d(1)
        # self.attention = OutlookAttention(dim=dim, num_heads=8)
        # self.attention = PixelAttention(dim)

    def forward(self, r, d):
        init = torch.matmul(r, d)
        r1 = self.gmp_RGB(r) * r
        d1 = self.gmp_Depth(d) * d
        # init_attn = torch.matmul(r1, d1).permute(0, 3, 2, 1)
        # attn = self.attention(init_attn).permute(0, 3, 2, 1)
        # init_fu = torch.matmul(r1, d1)
        # attn = torch.sigmoid(self.attention(init, init_fu))

        attn = torch.softmax(r1 * d1, dim=1)
        f_r = r * attn + d1
        f_d = d * attn + r1
        f = torch.cat([f_r, f_d], dim=1)
        f = self.conv1(f)
        return f


class InceptionDWConv2d(nn.Module):
    """ Inception depthweise convolution
    """

    def __init__(self, in_channels, square_kernel_size=3, band_kernel_size=11, branch_ratio=0.125):
        super().__init__()

        gc = int(in_channels * branch_ratio)  # channel numbers of a convolution branch
        self.dwconv_hw = nn.Conv2d(gc, gc, square_kernel_size, padding=square_kernel_size // 2, groups=gc)
        self.dwconv_w = nn.Conv2d(gc, gc, kernel_size=(1, band_kernel_size), padding=(0, band_kernel_size // 2),
                                  groups=gc)
        self.dwconv_h = nn.Conv2d(gc, gc, kernel_size=(band_kernel_size, 1), padding=(band_kernel_size // 2, 0),
                                  groups=gc)
        self.split_indexes = (in_channels - 3 * gc, gc, gc, gc)

    def forward(self, x):
        x_id, x_hw, x_w, x_h = torch.split(x, self.split_indexes, dim=1)
        return torch.cat(
            (x_id, self.dwconv_hw(x_hw), self.dwconv_w(x_w), self.dwconv_h(x_h)),
            dim=1,
        )


def MaskAveragePooling(x, mask):
    mask = torch.sigmoid(mask)
    b, c, h, w = x.shape
    eps = 0.0005
    x_mask = x * mask
    h, w = x.shape[2], x.shape[3]
    area = F.avg_pool2d(mask, (h, w)) * h * w + eps  #[1,1,1,1]
    x_feat = F.avg_pool2d(x_mask, (h, w)) * h * w / area  #[3,32,1,1]
    x_feat = x_feat.view(b, c, -1)
    return x_feat


class LayerNorm2d(nn.Module):
    r""" LayerNorm that supports two data formats: channels_last (default) or channels_first.
    The ordering of the dimensions in the inputs. channels_last corresponds to inputs with
    shape (batch_size, height, width, channels) while channels_first corresponds to inputs
    with shape (batch_size, channels, height, width).
    """

    def __init__(self,
                 normalized_shape,
                 eps=1e-6,
                 data_format="channels_last"):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.eps = eps
        self.data_format = data_format
        assert self.data_format in ["channels_last", "channels_first"]
        self.normalized_shape = (normalized_shape,)

    def forward(self, x):
        if self.data_format == "channels_last":
            return F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)
        elif self.data_format == "channels_first":
            u = x.mean(1, keepdim=True)
            s = (x - u).pow(2).mean(1, keepdim=True)
            x = (x - u) / torch.sqrt(s + self.eps)
            x = self.weight[:, None, None] * x + self.bias[:, None, None]
            return x


def build_act_layer(act_type):
    """Build activation layer."""
    if act_type is None:
        return nn.Identity()
    assert act_type in ['GELU', 'ReLU', 'SiLU']
    if act_type == 'SiLU':
        return nn.SiLU()
    elif act_type == 'ReLU':
        return nn.ReLU()
    else:
        return nn.GELU()


def build_norm_layer(norm_type, embed_dims):
    """Build normalization layer."""
    assert norm_type in ['BN', 'GN', 'LN2d', 'SyncBN']
    if norm_type == 'GN':
        return nn.GroupNorm(embed_dims, embed_dims, eps=1e-5)
    if norm_type == 'LN2d':
        return LayerNorm2d(embed_dims, eps=1e-6)
    if norm_type == 'SyncBN':
        return nn.SyncBatchNorm(embed_dims, eps=1e-5)
    else:
        return nn.BatchNorm2d(embed_dims, eps=1e-5)


class ElementScale(nn.Module):
    """A learnable element-wise scaler."""

    def __init__(self, embed_dims, init_value=0., requires_grad=True):
        super(ElementScale, self).__init__()
        self.scale = nn.Parameter(
            init_value * torch.ones((1, embed_dims, 1, 1)),
            requires_grad=requires_grad
        )

    def forward(self, x):
        return x * self.scale


class ChannelAggregationFFN(nn.Module):
    """An implementation of FFN with Channel Aggregation.

    Args:
        embed_dims (int): The feature dimension. Same as
            `MultiheadAttention`.
        feedforward_channels (int): The hidden dimension of FFNs.
        kernel_size (int): The depth-wise conv kernel size as the
            depth-wise convolution. Defaults to 3.
        act_type (str): The type of activation. Defaults to 'GELU'.
        ffn_drop (float, optional): Probability of an element to be
            zeroed in FFN. Default 0.0.
    """

    def __init__(self,
                 embed_dims,
                 feedforward_channels,
                 kernel_size=3,
                 act_type='GELU',
                 ffn_drop=0.):
        super(ChannelAggregationFFN, self).__init__()

        self.embed_dims = embed_dims
        self.feedforward_channels = feedforward_channels

        self.fc1 = nn.Conv2d(
            in_channels=embed_dims,
            out_channels=self.feedforward_channels,
            kernel_size=1)
        self.dwconv = nn.Conv2d(
            in_channels=self.feedforward_channels,
            out_channels=self.feedforward_channels,
            kernel_size=kernel_size,
            stride=1,
            padding=kernel_size // 2,
            bias=True,
            groups=self.feedforward_channels)
        self.act = build_act_layer(act_type)
        self.fc2 = nn.Conv2d(
            in_channels=feedforward_channels,
            out_channels=embed_dims,
            kernel_size=1)
        self.drop = nn.Dropout(ffn_drop)

        self.decompose = nn.Conv2d(
            in_channels=self.feedforward_channels,  # C -> 1
            out_channels=1, kernel_size=1,
        )
        self.sigma = ElementScale(
            self.feedforward_channels, init_value=1e-5, requires_grad=True)
        self.decompose_act = build_act_layer(act_type)
    def feat_decompose(self, x):
        # x_d: [B, C, H, W] -> [B, 1, H, W]
        x = x + self.sigma(x - self.decompose_act(self.decompose(x)))
        return x

    def forward(self, x):
        # proj 1
        x = self.fc1(x)
        x = self.dwconv(x)
        x = self.act(x)
        x = self.drop(x) # [1,256,24,24]
        # proj 2
        x = self.feat_decompose(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x


# class MultiOrderDWConv(nn.Module):
#     """Multi-order Features with Dilated DWConv Kernel.

#     Args:
#         embed_dims (int): Number of input channels.
#         dw_dilation (list): Dilations of three DWConv layers.
#         channel_split (list): The raletive ratio of three splited channels.
#     """

#     def __init__(self,
#                  embed_dims,
#                  dw_dilation=[1, 2, 3, ],
#                  channel_split=[1, 3, 4, ],
#                  ):
#         super(MultiOrderDWConv, self).__init__()

#         self.split_ratio = [i / sum(channel_split) for i in channel_split]
#         self.embed_dims_1 = int(self.split_ratio[1] * embed_dims)
#         self.embed_dims_2 = int(self.split_ratio[2] * embed_dims)
#         # self.embed_dims_3 = int(self.split_ratio[0] * embed_dims)
#         self.embed_dims_0 = embed_dims - self.embed_dims_1 - self.embed_dims_2
#         self.embed_dims = embed_dims
#         assert len(dw_dilation) == len(channel_split) == 3
#         assert 1 <= min(dw_dilation) and max(dw_dilation) <= 3
#         assert embed_dims % sum(channel_split) == 0

#         # basic DW conv
#         self.DW_conv0 = nn.Conv2d(
#             in_channels=self.embed_dims,
#             out_channels=self.embed_dims,
#             kernel_size=5,
#             padding=(1 + 4 * dw_dilation[0]) // 2,
#             groups=self.embed_dims,
#             stride=1, dilation=dw_dilation[0],
#         )
#         # DW conv 1 # C = 24
#         self.DW_conv1 = nn.Conv2d(
#             in_channels=self.embed_dims_1,
#             out_channels=self.embed_dims_1,
#             kernel_size=5,
#             padding=(1 + 4 * dw_dilation[1]) // 2,
#             groups=self.embed_dims_1,
#             stride=1, dilation=dw_dilation[1],
#         )
#         # DW conv 2  C = 32
#         self.DW_conv2 = nn.Conv2d(
#             in_channels=self.embed_dims_2,
#             out_channels=self.embed_dims_2,
#             kernel_size=7,
#             padding=(1 + 6 * dw_dilation[2]) // 2,
#             groups=self.embed_dims_2,
#             stride=1, dilation=dw_dilation[2],
#         )

#         # DW conv 3 C=8
#         self.DW_conv3 = nn.Conv2d(
#             in_channels=self.embed_dims_0,
#             out_channels=self.embed_dims_0,
#             kernel_size=3,
#             padding=1,
#             groups=self.embed_dims_0,
#             stride=1, dilation=dw_dilation[0],
#         )


#         # a channel convolution
#         self.PW_conv = nn.Conv2d(  # point-wise convolution
#             in_channels=embed_dims,
#             out_channels=embed_dims,
#             kernel_size=1)

#     def forward(self, x):
#         x_0 = self.DW_conv0(x)
#         x_1 = self.DW_conv1(
#             x_0[:, self.embed_dims_0: self.embed_dims_0 + self.embed_dims_1, ...])
#         x_2 = self.DW_conv2(
#             x_0[:, self.embed_dims - self.embed_dims_2:, ...])
#         x_3 = self.DW_conv3(
#             x_0[:,:self.embed_dims_0,...]
#         )
#         x = torch.cat([
#             x_3, x_1, x_2], dim=1)
#         x = self.PW_conv(x)
#         return x


# class MultiOrderGatedAggregation(nn.Module):
#     """Spatial Block with Multi-order Gated Aggregation.

#     Args:
#         embed_dims (int): Number of input channels.
#         attn_dw_dilation (list): Dilations of three DWConv layers.
#         attn_channel_split (list): The raletive ratio of splited channels.
#         attn_act_type (str): The activation type for Spatial Block.
#             Defaults to 'SiLU'.
#     """

#     def __init__(self,
#                  embed_dims,
#                  attn_dw_dilation=[1, 2, 3],
#                  attn_channel_split=[1, 3, 4],
#                  attn_act_type='SiLU',
#                  attn_force_fp32=False,
#                  ):
#         super(MultiOrderGatedAggregation, self).__init__()

#         self.embed_dims = embed_dims
#         self.attn_force_fp32 = attn_force_fp32
#         self.proj_1 = nn.Conv2d(
#             in_channels=embed_dims, out_channels=embed_dims, kernel_size=1)
#         self.gate = nn.Conv2d(
#             in_channels=embed_dims, out_channels=embed_dims, kernel_size=1)
#         self.value = MultiOrderDWConv(
#             embed_dims=embed_dims,
#             dw_dilation=attn_dw_dilation,
#             channel_split=attn_channel_split,
#         )
#         self.proj_2 = nn.Conv2d(
#             in_channels=embed_dims, out_channels=embed_dims, kernel_size=1)

#         # activation for gating and value
#         self.act_value = build_act_layer(attn_act_type)
#         self.act_gate = build_act_layer(attn_act_type)

#         # decompose
#         self.sigma = ElementScale(
#             embed_dims, init_value=1e-5, requires_grad=True)

#     def feat_decompose(self, x):
#         x = self.proj_1(x)
#         # x_d: [B, C, H, W] -> [B, C, 1, 1]
#         x_d = F.adaptive_avg_pool2d(x, output_size=1)
#         x = x + self.sigma(x - x_d)
#         x = self.act_value(x)
#         return x

#     def forward_gating(self, g, v):
#         with torch.cuda.amp.autocast(enabled=False):
#             g = g.to(torch.float32)
#             v = v.to(torch.float32)
#             return self.proj_2(self.act_gate(g) * self.act_gate(v))

#     def forward(self, x):
#         shortcut = x.clone()
#         # proj 1x1
#         x = self.feat_decompose(x)
#         # gating and value branch
#         g = self.gate(x)
#         v = self.value(x)
#         # aggregation
#         if not self.attn_force_fp32:
#             x = self.proj_2(self.act_gate(g) * self.act_gate(v))
#         else:
#             x = self.forward_gating(self.act_gate(g), self.act_gate(v))
#         x = x + shortcut
#         return x


class MultiOrderConv(nn.Module):
    def __init__(self, embed_dims, order=4):
        super(MultiOrderConv, self).__init__()

        self.order = order
        self.embed_dims = embed_dims
        
        base_dims = [max(1, self.embed_dims // 2 ** i) for i in range(order)]
        base_dims.reverse()
        
        current_sum = sum(base_dims)
        if current_sum != self.embed_dims:
            base_dims[-1] += (self.embed_dims - current_sum)
            
        self.dims = base_dims
        
        self.proj_in = nn.Conv2d(self.embed_dims, 2 * self.embed_dims, kernel_size=1)
        
        self.dwconvs = nn.ModuleList()
        for i in range(order):
            dim = self.dims[i]
            dilation = min(i + 1, 3) 
            kernel = 5 if dilation > 1 else 3
            padding = (kernel - 1) // 2 * dilation
            
            self.dwconvs.append(
                nn.Conv2d(dim, dim, kernel_size=kernel, padding=padding, 
                          groups=dim, stride=1, dilation=dilation)
            )
        self.pws = nn.ModuleList()
        for i in range(order - 1):
            self.pws.append(nn.Conv2d(self.dims[i], self.dims[i+1], kernel_size=1))

      
        self.proj_out = nn.Conv2d(self.dims[-1], embed_dims, kernel_size=1)

    def forward(self, x):
        fused_x = self.proj_in(x)
        pwa_feat, abc_feat = torch.split(fused_x, [self.embed_dims, self.embed_dims], dim=1)
        abc_list = torch.split(abc_feat, self.dims, dim=1)
        dw_list = []
        for i in range(self.order):
            dw_list.append(self.dwconvs[i](abc_list[i]))
        res = dw_list[0] * torch.split(pwa_feat, [self.dims[0], self.embed_dims - self.dims[0]], dim=1)[0]
    
        for i in range(self.order - 1):
            res = self.pws[i](res) * dw_list[i+1]
        out = self.proj_out(res)
        return out
    


class SimpleSelfAttention2d(nn.Module):
    def __init__(self, dim):
        super(SimpleSelfAttention2d, self).__init__()
        if dim % 4 == 0:
            self.num_heads = 4
        elif dim % 2 == 0:
            self.num_heads = 2
        else:
            self.num_heads = 1
        self.head_dim = dim // self.num_heads
        self.scale = self.head_dim ** -0.5
        self.qkv = nn.Conv2d(dim, dim * 3, kernel_size=1)
        self.proj = nn.Conv2d(dim, dim, kernel_size=1)

    def forward(self, x):
        B, C, H, W = x.shape
        N = H * W
        qkv = self.qkv(x).reshape(B, 3, self.num_heads, self.head_dim, N)
        q, k, v = qkv[:, 0], qkv[:, 1], qkv[:, 2] 
        attn = (q.transpose(-1, -2) @ k) * self.scale
        attn = attn.softmax(dim=-1)
        out = (v @ attn.transpose(-1, -2))
        out = out.reshape(B, C, H, W)
        return self.proj(out)


class MultiOrderAttention(nn.Module):
    def __init__(self, embed_dims, order=4):
        super(MultiOrderAttention, self).__init__()

        self.embed_dims = embed_dims
        self.order = order
        dims = []
        rem = embed_dims
        for i in range(order - 1):
            d = rem // 2
            dims.append(max(1, d))
            rem -= max(1, d)
        dims.append(max(1, rem))
        dims.reverse() 
        self.dims = dims
        self.proj_in = nn.Conv2d(embed_dims, 2 * embed_dims, kernel_size=1)
        
    
        self.attentions = nn.ModuleList()
        for i in range(order):
            dim = self.dims[i]
            self.attentions.append(SimpleSelfAttention2d(dim))
        self.pws = nn.ModuleList(
            [nn.Conv2d(self.dims[i], self.dims[i+1], kernel_size=1) for i in range(order - 1)]
        )
        self.proj_out = nn.Conv2d(self.dims[-1], embed_dims, kernel_size=1)

    def forward(self, x):
        fused_x = self.proj_in(x)
        pwa_feat, abc_feat = torch.split(fused_x, [self.embed_dims, self.embed_dims], dim=1)
        abc_list = torch.split(abc_feat, self.dims, dim=1)
        attn_list = []
        for i in range(self.order):
            attn_list.append(self.attentions[i](abc_list[i]))
        pwa_init = torch.split(pwa_feat, [self.dims[0], self.embed_dims - self.dims[0]], dim=1)[0]
        res = pwa_init * attn_list[0]
        
        for i in range(self.order - 1):
            res = self.pws[i](res) * attn_list[i+1]
        out = self.proj_out(res)
        return out


class MultiOrderGatedAggregation(nn.Module):
    def __init__(self,
                 embed_dims,
                 order=4,           
                 attn_act_type='SiLU',
                 attn_force_fp32=False,
                 ):
        super(MultiOrderGatedAggregation, self).__init__()

        self.embed_dims = embed_dims
        self.attn_force_fp32 = attn_force_fp32
        
        self.proj_1 = nn.Conv2d(
            in_channels=embed_dims, out_channels=embed_dims, kernel_size=1)
        self.gate = nn.Conv2d(
            in_channels=embed_dims, out_channels=embed_dims, kernel_size=1)
        
        # self.value = MultiOrderConv(
        #     embed_dims=embed_dims,
        #     order=order,
        # )
            
       
        self.value = MultiOrderAttention(
            embed_dims=embed_dims,
            order=order,
        )
        
        self.proj_2 = nn.Conv2d(
            in_channels=embed_dims, out_channels=embed_dims, kernel_size=1)

        self.act_value = build_act_layer(attn_act_type)
        self.act_gate = build_act_layer(attn_act_type)

        self.sigma = ElementScale(
            embed_dims, init_value=1e-5, requires_grad=True)

    def feat_decompose(self, x):
        x = self.proj_1(x)
        x_d = F.adaptive_avg_pool2d(x, output_size=1)
        x = x + self.sigma(x - x_d)
        x = self.act_value(x)
        return x

    def forward_gating(self, g, v):
        g = g.to(torch.float32)
        v = v.to(torch.float32)
        return self.proj_2(g * v) 

    def forward(self, x):
        shortcut = x.clone()
        x = self.feat_decompose(x)
        g = self.gate(x)
        v = self.value(x) 
        
        act_g = self.act_gate(g)
        act_v = self.act_gate(v)
        
        if not self.attn_force_fp32:
            x = self.proj_2(act_g * act_v)
        else:
            x = self.forward_gating(act_g, act_v)
        x = x + shortcut
        return x

class MogaBlock(nn.Module):
    def __init__(self,
                embed_dims,
                 ffn_ratio=4.,
                 drop_rate=0.,
                 drop_path_rate=0.,
                 act_type='GELU',
                 norm_type='BN',
                 init_value=1e-5,
                 order=4,
                 attn_act_type='SiLU',
                 attn_force_fp32=True,
                 ):
        super(MogaBlock, self).__init__()
        self.out_channels = embed_dims

        self.norm1 = build_norm_layer(norm_type, embed_dims)

        # spatial attention
        # self.attn = MultiOrderGatedAggregation(
        #     embed_dims,
        #     attn_dw_dilation=attn_dw_dilation,
        #     attn_channel_split=attn_channel_split,
        #     attn_act_type=attn_act_type,
        #     attn_force_fp32=attn_force_fp32,
        # )
        self.attn = MultiOrderGatedAggregation(
            embed_dims=embed_dims,
            order=order,                   
            attn_act_type=attn_act_type,
            attn_force_fp32=attn_force_fp32,
        )
        self.drop_path = DropPath(
            drop_path_rate) if drop_path_rate > 0. else nn.Identity()

        self.norm2 = build_norm_layer(norm_type, embed_dims)

        # channel MLP
        mlp_hidden_dim = int(embed_dims * ffn_ratio)
        self.mlp = ChannelAggregationFFN(  # DWConv + Channel Aggregation FFN
            embed_dims=embed_dims,
            feedforward_channels=mlp_hidden_dim,
            act_type=act_type,
            ffn_drop=drop_rate,
        )

        # init layer scale
        self.layer_scale_1 = nn.Parameter(
            init_value * torch.ones((1, embed_dims, 1, 1)), requires_grad=True)
        self.layer_scale_2 = nn.Parameter(
            init_value * torch.ones((1, embed_dims, 1, 1)), requires_grad=True)

    def forward(self, x):
        # spatial
        identity = x
        x = self.layer_scale_1 * self.attn(self.norm1(x))
        x = identity + self.drop_path(x)
        # channel
        identity = x
        x = self.layer_scale_2 * self.mlp(self.norm2(x))
        x = identity + self.drop_path(x)
        return x


class ChannelProjection(nn.Module):
    """ Channel Projection.
    Args:
        dim (int): input channels.
    """

    def __init__(self, dim):
        super().__init__()
        self.pro_in = nn.Conv2d(dim, dim // 6, 1, 1, 0)
        self.CI1 = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim // 6, dim // 6, kernel_size=1)
        )
        self.CI2 = nn.Sequential(
            nn.Conv2d(dim // 6, dim // 6, kernel_size=3, stride=1, padding=1, groups=dim // 6),
            nn.Conv2d(dim // 6, dim // 6, 7, stride=1, padding=9, groups=dim // 6, dilation=3),
            nn.Conv2d(dim // 6, dim // 6, kernel_size=1)
        )
        self.pro_out = nn.Conv2d(dim // 6, dim, kernel_size=1)

    def forward(self, x):
        """
        Input: x: (B, C, H, W)
        Output: x: (B, C, H, W)
        """
        x = self.pro_in(x)
        res = x
        ci1 = self.CI1(x)
        ci2 = self.CI2(x)
        out = self.pro_out(res * ci1 * ci2)
        return out


class SpatialProjection(nn.Module):
    """ Spatial Projection.
    Args:
        dim (int): input channels.
    """

    def __init__(self, dim):
        super().__init__()
        self.pro_in = nn.Conv2d(dim, dim // 6, 1, 1, 0)
        self.dwconv = nn.Conv2d(dim // 6, dim // 6, kernel_size=3, stride=1, padding=1, groups=dim // 6)
        self.pro_out = nn.Conv2d(dim // 12, dim, kernel_size=1)

    def forward(self, x):
        """
        Input: x: (B, C, H, W)
        Output: x: (B, C, H, W)
        """
        x = self.pro_in(x)
        x1, x2 = self.dwconv(x).chunk(2, dim=1)
        x = F.gelu(x1) * x2
        x = self.pro_out(x)
        return x


class Channel_Transposed_Attention(nn.Module):
    # The implementation builds on XCiT code https://github.com/facebookresearch/xcit
    """ Channel Transposed Self-Attention
    Args:
        dim (int): Number of input channels.
        num_heads (int): Number of attention heads. Default: 6
        qkv_bias (bool): If True, add a learnable bias to query, key, value. Default: True
        qk_scale (float | None): Override default qk scale of head_dim ** -0.5 if set.
        attn_drop (float): Attention dropout rate. Default: 0.0
        drop_path (float): Stochastic depth rate. Default: 0.0
    """

    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.):
        super().__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

        self.channel_projection = ChannelProjection(dim)
        self.spatial_projection = SpatialProjection(dim)
        self.dwconv = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=1),
            nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1, groups=dim),
        )

        # self.frequency_projection = FrequencyProjection(dim)

    def forward(self, x, H, W):
        """
        Input: x: (B, H*W, C), H, W
        Output: x: (B, H*W, C)
        """
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads)
        qkv = qkv.permute(2, 0, 3, 1, 4)  #  3 B num_heads N D
        q, k, v = qkv[0], qkv[1], qkv[2]

        #  B num_heads D N
        q = q.transpose(-2, -1)
        k = k.transpose(-2, -1)
        v = v.transpose(-2, -1)

        v_ = v.reshape(B, C, N).contiguous().view(B, C, H, W)

        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)

        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        # attention output
        attened_x = (attn @ v).permute(0, 3, 1, 2).reshape(B, N, C)

        # convolution output
        conv_x = self.dwconv(v_)

        # C-Map (before sigmoid)
        attention_reshape = attened_x.transpose(-2, -1).contiguous().view(B, C, H, W)
        channel_map = self.channel_projection(attention_reshape)
        attened_x = attened_x + channel_map.permute(0, 2, 3, 1).contiguous().view(B, N, C)
        channel_map = reduce(channel_map, 'b c h w -> b c 1 1', 'mean')

        # S-Map (before sigmoid)
        spatial_map = self.spatial_projection(conv_x).permute(0, 2, 3, 1).contiguous().view(B, N, C)

        # S-I
        attened_x = attened_x * torch.sigmoid(spatial_map)
        # C-I
        conv_x = conv_x * torch.sigmoid(channel_map)
        conv_x = conv_x.permute(0, 2, 3, 1).contiguous().view(B, N, C)

        x = attened_x + conv_x

        x = self.proj(x)

        x = self.proj_drop(x)

        return x


if __name__ == '__main__':
    # mask = torch.randn([1, 1, 48, 48])
    # f = torch.randn([1, 64, 24, 24])
    # block = LCA_blcok(dim=64)
    # re = block(f, mask)
    # print(re.shape)
    # block1 = DySample(12)
    # input = torch.rand(2, 12, 7, 7)  # 输入 B C H W
    # output = block1(input)
    # print(input.size())
    # print(output.size())
    # block = MFFM(dim=32)
    # input1 = torch.rand(3, 32, 64, 64)  # 输入 N C H W
    # input2 = torch.rand(3, 32, 64, 64)
    # output = block(input1, input2)
    # print(output.size())
    # block = InceptionDWConv2d(64)  # 输入C
    # input = torch.randn(1, 64, 224, 224)  # 输入 B C H W
    # output = block(input)
    # print(input.size())
    # print(output.size())
    # block = OutlookAttention(dim=32, num_heads=8).cuda()
    mask = torch.randn([1, 1, 64, 64])
    input = torch.rand(1, 32, 64, 64)
    output = MaskAveragePooling(input, mask)
    print(input.size(), output.size())
    block = MogaBlock(embed_dims=32)
    re = block(input)
    print(re.shape)
